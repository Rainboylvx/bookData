/* author: Rainboy  email: rainboylvx@qq.com  time: 2020年 10月 19日 星期一 10:28:53 CST */
#include <bits/stdc++.h>
using namespace std;

#ifndef DEBUG
#define debug(...)
#endif

const int maxn = 1e6+5;
const int maxe = 1e6+5;
int n,m;

struct xlx {
    typedef struct {int u,v,w,next;} edge;
    edge e[maxe];
    int h[maxn],edge_cnt=0;
    xlx(){
        edge_cnt=0;
        memset(h,-1,sizeof(h));
    }
    void add(int u,int v,int w=0){
        e[edge_cnt] = {u,v,w,h[u]};
        h[u] = edge_cnt++;
    }
    void add2(int u,int v,int w=0){
        add(u,v,w);
        add(v,u,w);
    }
    edge& operator[](int i){
        return e[i];
    }
};

xlx x1;
int main(){
    clock_t program_start_clock = clock(); //开始记时
    scanf("%d%d",&n,&m);
    int i,j;
    for(i=1;i<=m;++i){
        int u,v,w;
        scanf("%d%d",&u,&v);
        x1.add2(u,v);
    }
    for(i=x1.h[1]; ~i ;i = x1[i].next){
        int v = x1[i].v;
        printf("%d ",v);
    }
    printf("\n");
    fprintf(stderr,"\n Total Time: %lf ms",double(clock()-program_start_clock)/(CLOCKS_PER_SEC / 1000));
    return 0;
}
