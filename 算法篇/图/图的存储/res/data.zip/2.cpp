/* author: Rainboy  email: rainboylvx@qq.com  time: 2020年 10月 19日 星期一 10:43:47 CST */
#include <bits/stdc++.h>
using namespace std;

#ifndef DEBUG
#define debug(...)
#endif

const int maxn = 1e6+5;
int n,m;

struct linkList {
    typedef struct {int v,w;} edge;
    vector<edge> e[maxn];
    void add(int u,int v,int w=0){
        e[u].push_back({v,w});
    }
    void add2(int u,int v,int w=0){
        add(u,v,w);
        add(v,u,w);
    }
    vector<edge>& operator[](int i){
        return e[i];
    }
};

linkList x1;
int main(){

    clock_t program_start_clock = clock(); //开始记时
    scanf("%d%d",&n,&m);
    int i,j;
    for(i=1;i<=m;++i){
        int u,v,w;
        scanf("%d%d",&u,&v);
        x1.add2(u,v);
    }
    for(i = 0 ;i< x1[1].size();i++){
        printf("%d ",x1[1][i].v);
    }
    printf("\n");
    fprintf(stderr,"\n Total Time: %lf ms",double(clock()-program_start_clock)/(CLOCKS_PER_SEC / 1000));
    return 0;
}
